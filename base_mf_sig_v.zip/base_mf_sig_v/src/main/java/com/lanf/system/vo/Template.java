package com.lanf.system.vo;

import lombok.Data;

@Data
public class Template {
    //包名
    private String packageName;
    //处理类名
    private String className;
    //模块名称
    private String moduleName;
}
