package com.lanf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/**
 * @author tanlingfei
 * @version 1.0
 * @description TODO
 * @date 2023/5/1 18:30
 */
@SpringBootApplication
public class BaseApp {

    public static void main(String[] args) {
        SpringApplication.run(BaseApp.class, args);
    }

}
