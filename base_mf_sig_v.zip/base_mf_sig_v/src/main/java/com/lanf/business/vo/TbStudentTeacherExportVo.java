package com.lanf.business.vo;

import io.swagger.annotations.ApiModel;
import lombok.Data;

/**
 * @author tanlingfei
 * @version 1.0
 * @description 学生讲师关系表 导出类
 * @date 2023-11-23 16:56:48
 */
@Data
@ApiModel(description = "学生讲师关系表")
public class TbStudentTeacherExportVo {
}
