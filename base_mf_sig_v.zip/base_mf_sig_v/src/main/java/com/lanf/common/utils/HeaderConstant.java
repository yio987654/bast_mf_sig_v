package com.lanf.common.utils;

public interface HeaderConstant {
     static  String  token = "token";
}
