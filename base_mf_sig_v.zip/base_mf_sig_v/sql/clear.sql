delete  FROM `sys_dept` where is_deleted=1;
delete  FROM `sys_dic` where is_deleted=1;
delete  FROM `sys_dic_item` where is_deleted=1;
delete  FROM `sys_form` where is_deleted=1;
delete  FROM `sys_form_item` where is_deleted=1;
delete  FROM `sys_login_log` where is_deleted=1;
delete  FROM `sys_menu` where is_deleted=1;
delete  FROM `sys_oper_log` where is_deleted=1;
delete  FROM `sys_post` where is_deleted=1;
delete  FROM `sys_role` where is_deleted=1;
delete  FROM `sys_role_menu` where is_deleted=1;
delete  FROM `sys_user` where is_deleted=1;
delete  FROM `sys_user_dept` where is_deleted=1;
delete  FROM `sys_user_role` where is_deleted=1;
d